import './brief-core.mjs';

const mount = document.querySelector('[data-tool]');
if (mount) {
  const loaders = {
    evaluation: () => import('./evaluation.mjs'),
    decision: () => import('./decision.mjs'),
    context: () => import('./context.mjs'),
    claims: () => import('./claims.mjs'),
  };
  try {
    if (mount.dataset.tool === 'brief') mountBrief(mount);
    else if (loaders[mount.dataset.tool]) (await loaders[mount.dataset.tool]()).mount(mount);
  } catch (error) {
    const message = document.createElement('p');
    message.className = 'error';
    message.setAttribute('role','alert');
    message.textContent = 'This tool could not start. Please reload the page. ' + error.message;
    mount.replaceChildren(message);
  }
}

function mountBrief(container) {
  container.innerHTML = `<p class="muted">A little structure before the first line of code. This uses a deterministic template; no AI service is called.</p>
    <form class="tool-form"><label>What do you want to build?<textarea name="idea" maxlength="4000" required>Turn meeting notes into clear decisions and next steps.</textarea></label>
    <div class="field-grid"><label>Who is it for?<input name="audience" maxlength="1000" value="Small teams who want less admin."></label><label>What constraints matter?<input name="constraint" maxlength="1000" value="Runs in the browser. No account or paid API."></label></div>
    <label>What would success look like?<input name="success" maxlength="1000" value="Every action has an owner and a due date."></label><div class="tool-actions"><button type="submit">Build my brief ↗</button><button type="button" data-save>Save as Markdown</button></div></form>
    <p class="error" role="alert" hidden></p><div class="tool-result" aria-live="polite"><pre class="brief"></pre></div>`;
  const form=container.querySelector('form');
  const result=container.querySelector('pre');
  const error=container.querySelector('[role=alert]');
  let current='';
  function build() {
    const brief=globalThis.RoaryBrief.buildBrief(Object.fromEntries(new FormData(form)));
    current=brief.text;
    result.textContent=brief.text;
    error.hidden=brief.ok;
    error.textContent=brief.error;
    return brief.ok;
  }
  form.addEventListener('submit',event=>{event.preventDefault();build();});
  container.querySelector('[data-save]').addEventListener('click',()=>{
    if (!build()) return;
    const link=document.createElement('a');
    const url=URL.createObjectURL(new Blob([current],{type:'text/markdown;charset=utf-8'}));
    link.href=url; link.download='roary-project-brief.md'; link.click();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
  build();
}
