const clean = (value) => typeof value === 'string' ? value.trim() : '';

export function createBlindPair(input = {}, flip = false) {
  const answerA = clean(input.answerA);
  const answerB = clean(input.answerB);
  if (!answerA || !answerB) throw new Error('Provide two non-blank answers to compare.');
  const answers = [
    { text: answerA, source: clean(input.sourceA) || 'Answer source A', original: 'A' },
    { text: answerB, source: clean(input.sourceB) || 'Answer source B', original: 'B' },
  ];
  if (flip) answers.reverse();
  return { responses: answers.map((answer, index) => ({ ...answer, slot: index + 1 })) };
}

export function tallyRubric(input = {}) {
  if (!Array.isArray(input.criteria) || !input.criteria.length) throw new Error('Add at least one named criterion.');
  const criteria = input.criteria.map(clean);
  if (criteria.some((criterion) => !criterion)) throw new Error('Give every criterion a name.');
  const valid1 = input.valid1 ?? true;
  const valid2 = input.valid2 ?? true;
  if (typeof valid1 !== 'boolean' || typeof valid2 !== 'boolean') throw new Error('Validity flags must be true or false.');
  const comparisonValid = valid1 && valid2;
  const validateScores = (scores) => {
    if (!Array.isArray(scores) || scores.length !== criteria.length) throw new Error('Supply one score per criterion for each response.');
    return scores.map((score) => {
      if (score === null && !comparisonValid) return null;
      if (typeof score !== 'number' || !Number.isInteger(score) || score < 0 || score > 5) {
        throw new Error('Score each valid comparison from 0 to 5, or mark an invalid response.');
      }
      return score;
    });
  };
  const scores1 = validateScores(input.scores1);
  const scores2 = validateScores(input.scores2);
  const sum = (scores) => scores.includes(null) ? null : scores.reduce((total, score) => total + score, 0);
  const total1 = sum(scores1);
  const total2 = sum(scores2);
  const verdict = !comparisonValid ? 'invalid' : total1 === total2 ? 'tie' : total1 > total2 ? 'response-1' : 'response-2';
  return { criteria, scores1, scores2, valid1, valid2, total1, total2, maxScore: criteria.length * 5, verdict };
}

export function mount(container) {
  const doc = container.ownerDocument;
  const element = (tag, text, className = '') => {
    const node = doc.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (className) node.className = className;
    return node;
  };
  container.innerHTML = `
    <p>Compare two saved answers against your own rubric. No model calls or automated fact checking.</p>
    <p class="muted">Content stays in this page’s memory until you leave or reload. If you supplied the answers yourself, hiding labels cannot remove what you already know.</p>
    <p data-provenance class="muted" role="status" hidden></p>
    <p class="error" role="alert" hidden></p>
    <form class="tool-form" data-setup>
      <label>Task or question (optional)<textarea name="task" rows="2"></textarea></label>
      <div class="field-grid">
        <label>Source A label<input name="sourceA" value="Answer source A" maxlength="120"></label>
        <label>Source B label<input name="sourceB" value="Answer source B" maxlength="120"></label>
        <label>Answer A<textarea name="answerA" rows="6" required></textarea></label>
        <label>Answer B<textarea name="answerB" rows="6" required></textarea></label>
      </div>
      <fieldset><legend>Set your rubric before comparing</legend>
        <p class="muted">Equal weight for each criterion. Use 0 = poor, 5 = excellent. Check factual claims against reference material yourself.</p>
        <div class="field-grid">
          <label>Criterion 1<input name="criterion" value="Correctness" required maxlength="100"></label>
          <label>Criterion 2<input name="criterion" value="Clarity" required maxlength="100"></label>
          <label>Criterion 3<input name="criterion" value="Usefulness" required maxlength="100"></label>
        </div>
      </fieldset>
      <div class="tool-actions"><button type="submit">Hide labels and compare</button><button type="button" data-example>Load illustrative example</button><button type="button" data-clear>Clear setup and start fresh</button></div>
    </form>
    <section data-assessment hidden aria-label="Score the blinded responses">
      <p data-task class="muted"></p>
      <div class="field-grid" data-answers></div>
      <form class="tool-form" data-score-form>
        <h4>Score the responses</h4>
        <div data-scores></div>
        <fieldset><legend>Validity</legend>
          <label><input type="checkbox" name="valid1" checked> Response 1 is valid for this task</label>
          <label><input type="checkbox" name="valid2" checked> Response 2 is valid for this task</label>
          <p class="muted">Untick a response if it is incomplete, refuses the task, or otherwise cannot be assessed. Invalid comparisons stay in the export; they have no winner.</p>
        </fieldset>
        <label>Assessment notes (optional)<textarea name="notes" rows="2" placeholder="Evidence, limitations, or reason a response is invalid"></textarea></label>
        <button type="submit" data-record>Record assessment</button>
      </form>
      <div class="tool-result" data-result role="status" aria-live="polite"></div>
      <div class="tool-actions"><button type="button" data-reveal disabled>Reveal source labels</button><button type="button" data-export disabled>Export assessment JSON</button><button type="button" data-restart>Start again</button></div>
      <p class="muted">A single exploratory assessment reflects your rubric and scores. It is not a model benchmark. Export includes source labels, answer text, validity and notes.</p>
    </section>`;

  const setup = container.querySelector('[data-setup]');
  const assessment = container.querySelector('[data-assessment]');
  const scoreForm = container.querySelector('[data-score-form]');
  const error = container.querySelector('.error');
  const result = container.querySelector('[data-result]');
  const provenanceNotice = container.querySelector('[data-provenance]');
  const revealButton = container.querySelector('[data-reveal]');
  const exportButton = container.querySelector('[data-export]');
  let pair;
  let criteria;
  let task = '';
  let record = null;
  let revealed = false;
  let provenance = { origin: 'user-supplied', exampleEdited: null };
  const showError = (message = '') => { error.textContent = message; error.hidden = !message; };
  const setupField = (name) => setup.elements.namedItem(name);
  const describeProvenance = () => provenance.origin === 'illustrative-example'
    ? `This comparison started from an illustrative example${provenance.exampleEdited ? ' and was edited during setup' : ''}. Its original answers are synthetic.`
    : '';
  const renderProvenance = () => {
    provenanceNotice.textContent = describeProvenance();
    provenanceNotice.hidden = provenance.origin !== 'illustrative-example';
  };

  container.querySelector('[data-example]').addEventListener('click', () => {
    setupField('task').value = 'Explain caching to someone new to software.';
    setupField('sourceA').value = 'Illustrative source A';
    setupField('sourceB').value = 'Illustrative source B';
    setupField('answerA').value = 'A cache keeps a copy of something expensive to fetch or calculate. Reusing the copy can be faster, but you need a plan for refreshing old data.';
    setupField('answerB').value = 'Caching means storing a result so it can be reused. Once cached, data never needs to be refreshed because cached copies are always current.';
    provenance = { origin: 'illustrative-example', exampleEdited: false };
    renderProvenance();
    showError();
  });

  setup.addEventListener('input', () => {
    if (provenance.origin === 'illustrative-example') {
      provenance = { ...provenance, exampleEdited: true };
      renderProvenance();
    }
  });

  container.querySelector('[data-clear]').addEventListener('click', () => {
    setup.reset();
    provenance = { origin: 'user-supplied', exampleEdited: null };
    record = null;
    revealButton.disabled = true;
    exportButton.disabled = true;
    renderProvenance();
    showError();
    setupField('task').focus();
  });

  setup.addEventListener('submit', (event) => {
    event.preventDefault();
    try {
      criteria = [...setup.querySelectorAll('[name="criterion"]')].map((field) => field.value.trim());
      if (criteria.some((criterion) => !criterion)) throw new Error('Give every criterion a name.');
      const bytes = new Uint8Array(1);
      if (!globalThis.crypto?.getRandomValues) throw new Error('This browser cannot securely randomise response order. Try a current browser.');
      globalThis.crypto.getRandomValues(bytes);
      pair = createBlindPair({
        sourceA: setupField('sourceA').value, sourceB: setupField('sourceB').value,
        answerA: setupField('answerA').value, answerB: setupField('answerB').value,
      }, Boolean(bytes[0] & 1));
      task = setupField('task').value.trim();
      revealed = false;
      record = null;
      revealButton.disabled = true;
      exportButton.disabled = true;
      revealButton.textContent = 'Reveal source labels';
      result.textContent = '';
      scoreForm.reset();
      container.querySelector('[data-record]').textContent = 'Record assessment';
      container.querySelector('[data-task]').textContent = task ? `Task: ${task}` : 'No task recorded.';
      const answers = container.querySelector('[data-answers]');
      answers.replaceChildren();
      for (const response of pair.responses) {
        const article = element('article', undefined, 'tool-result');
        article.append(element('h4', `Response ${response.slot}`));
        const answerText = element('p', response.text);
        answerText.style.whiteSpace = 'pre-wrap';
        article.append(answerText);
        const identity = element('p', '', 'muted');
        identity.dataset.identity = String(response.slot);
        identity.hidden = true;
        article.append(identity);
        answers.append(article);
      }
      const scoreArea = container.querySelector('[data-scores]');
      scoreArea.replaceChildren();
      criteria.forEach((criterion, index) => {
        const fieldset = element('fieldset');
        fieldset.append(element('legend', criterion));
        const grid = element('div', undefined, 'field-grid');
        for (const slot of [1, 2]) {
          const label = element('label', `Response ${slot} score`);
          const select = element('select');
          select.name = `score-${slot}-${index}`;
          const blank = element('option', 'Choose score');
          blank.value = '';
          select.append(blank);
          for (let value = 0; value <= 5; value += 1) {
            const option = element('option', `${value}${value === 0 ? ' — poor' : value === 5 ? ' — excellent' : ''}`);
            option.value = String(value);
            select.append(option);
          }
          label.append(select);
          grid.append(label);
        }
        fieldset.append(grid);
        scoreArea.append(fieldset);
      });
      setup.hidden = true;
      assessment.hidden = false;
      showError();
      scoreArea.querySelector('select').focus();
    } catch (failure) { showError(failure.message); }
  });

  scoreForm.addEventListener('input', () => {
    record = null;
    exportButton.disabled = true;
    revealButton.disabled = true;
    result.textContent = 'Inputs changed. Record this assessment to update the result.';
    container.querySelector('[data-record]').textContent = revealed ? 'Update assessment (identities revealed)' : 'Record assessment';
  });

  scoreForm.addEventListener('submit', (event) => {
    event.preventDefault();
    try {
      const scores = (slot) => criteria.map((_, index) => {
        const value = scoreForm.elements.namedItem(`score-${slot}-${index}`).value;
        return value === '' ? null : Number(value);
      });
      const tally = tallyRubric({
        criteria, scores1: scores(1), scores2: scores(2),
        valid1: scoreForm.elements.namedItem('valid1').checked,
        valid2: scoreForm.elements.namedItem('valid2').checked,
      });
      record = {
        schemaVersion: 1, kind: 'exploratory-assessment', task,
        limit: 'One user-scored comparison; not a model benchmark or independent verification.',
        provenance: { ...provenance, notice: describeProvenance() },
        identitiesRevealedBeforeLatestAssessment: revealed,
        responses: pair.responses, assessment: tally,
        notes: scoreForm.elements.namedItem('notes').value.trim(),
      };
      const outcomes = { invalid: 'Invalid comparison retained. No winner is assigned.', tie: 'Tie on your rubric.', 'response-1': 'Response 1 scored higher on your rubric.', 'response-2': 'Response 2 scored higher on your rubric.' };
      result.textContent = `${outcomes[tally.verdict]}${tally.verdict === 'invalid' ? '' : ` Response 1: ${tally.total1}/${tally.maxScore}; Response 2: ${tally.total2}/${tally.maxScore}.`}${revealed ? ' This revision was scored after identities were revealed.' : ''}`;
      revealButton.disabled = revealed;
      exportButton.disabled = false;
      showError();
    } catch (failure) { showError(failure.message); }
  });

  revealButton.addEventListener('click', () => {
    if (!record) return;
    revealed = true;
    for (const response of pair.responses) {
      const identity = container.querySelector(`[data-identity="${response.slot}"]`);
      identity.textContent = `Source: ${response.source} (original input ${response.original})`;
      identity.hidden = false;
    }
    revealButton.disabled = true;
    revealButton.textContent = 'Source labels revealed';
  });

  exportButton.addEventListener('click', () => {
    if (!record) return;
    const url = URL.createObjectURL(new Blob([JSON.stringify(record, null, 2)], { type: 'application/json' }));
    const link = element('a');
    link.href = url;
    link.download = 'roary-exploratory-assessment.json';
    container.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });

  container.querySelector('[data-restart]').addEventListener('click', () => {
    assessment.hidden = true;
    setup.hidden = false;
    record = null;
    showError();
    setupField('task').focus();
  });
}
