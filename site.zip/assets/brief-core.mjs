(function exposeBrief(root) {
  'use strict';

  function trimmed(value) {
    return typeof value === 'string' ? value.trim() : '';
  }

  function buildBrief(input) {
    const fields = input || {};
    const idea = trimmed(fields.idea);

    if (!idea) {
      return { ok: false, text: '', error: 'Describe what you want to build.' };
    }

    const audience = trimmed(fields.audience)
      || 'To confirm: who will use this and what they need.';
    const constraint = trimmed(fields.constraint)
      || 'To confirm: budget, privacy, accessibility and delivery constraints.';
    const success = trimmed(fields.success)
      || 'To confirm: an observable result that would make the prototype useful.';

    const text = [
      `Problem\n${idea}`,
      `Audience\n${audience}`,
      `Constraints\n${constraint}`,
      `Acceptance checks\n- ${success}`,
      [
        'Build approach',
        '- Build the smallest reversible prototype.',
        '- Write a failing test before implementing behaviour, then make it pass.',
        '- Review the result against the acceptance checks before expanding scope.',
      ].join('\n'),
    ].join('\n\n');

    return { ok: true, text, error: '' };
  }

  const api = { buildBrief };
  root.RoaryBrief = api;
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  }
}(globalThis));
