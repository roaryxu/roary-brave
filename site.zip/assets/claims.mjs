const STATUSES = new Set(['support', 'conflict', 'unknown']);
const MAX_CLAIMS = 200;
const MAX_FILE_CHARACTERS = 2_000_000;

function string(value, label, maximum, required = false) {
  if (typeof value !== 'string') throw new TypeError(`${label} must be text.`);
  const clean = value.trim();
  if ((required && !clean) || clean.length > maximum) throw new RangeError(`${label} ${!clean ? 'is required' : `must be no longer than ${maximum} characters`}.`);
  return clean;
}

export function createClaim(input, id) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new TypeError('Each claim must be an object.');
  if (typeof id !== 'string' || !/^[A-Za-z0-9_-]{1,80}$/.test(id)) throw new TypeError('Each claim needs a valid ID.');
  const text = string(input.text, 'Claim', 3000, true);
  const note = string(input.note ?? '', 'Evidence note', 6000);
  const suppliedUrl = string(input.evidenceUrl ?? '', 'Evidence URL', 2000);
  let evidenceUrl = '';
  if (suppliedUrl) {
    let url;
    try { url = new URL(suppliedUrl); } catch { throw new TypeError('Evidence URL must be a complete http:// or https:// address.'); }
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw new TypeError('Use an http:// or https:// evidence URL without embedded credentials.');
    evidenceUrl = url.href;
  }
  if (!STATUSES.has(input.status)) throw new TypeError('Choose support, conflict or unknown.');
  return { id, text, evidenceUrl, note, status: input.status };
}

function validateClaims(claims) {
  if (!Array.isArray(claims) || claims.length > MAX_CLAIMS) throw new RangeError(`A ledger can contain up to ${MAX_CLAIMS} claims.`);
  const clean = claims.map((claim) => createClaim(claim, claim?.id));
  if (new Set(clean.map((claim) => claim.id)).size !== clean.length) throw new TypeError('Claim IDs must be unique.');
  return clean;
}

export function addClaim(claims, input, id) {
  return validateClaims([...validateClaims(claims), createClaim(input, id)]);
}

export function removeClaim(claims, id) {
  return validateClaims(claims).filter((claim) => claim.id !== id);
}

export function exportLedger(claims) {
  return JSON.stringify({ version: 1, claims: validateClaims(claims) }, null, 2);
}

export function importLedger(json) {
  if (typeof json !== 'string' || json.length > MAX_FILE_CHARACTERS) throw new RangeError('Import a JSON file smaller than 2 MB.');
  let data;
  try { data = JSON.parse(json); } catch { throw new TypeError('This file is not valid JSON.'); }
  if (!data || data.version !== 1) throw new TypeError('This is not a supported version 1 claim ledger.');
  return validateClaims(data.claims);
}

let mounts = 0;

export function mount(container) {
  const prefix = `claims-${++mounts}`;
  let claims = [];
  let sequence = 0;
  container.innerHTML = `
    <p class="muted">Keep a small evidence ledger while researching or reviewing an AI answer. This tool organises supplied links and your classifications. It does not fetch sources or verify claims. Data stays in this tab and is lost on refresh unless you export it.</p>
    <form class="tool-form" novalidate>
      <label for="${prefix}-text">Claim to examine<textarea id="${prefix}-text" name="text" rows="3" maxlength="3000" required placeholder="One specific statement you want to check…"></textarea></label>
      <div class="field-grid">
        <label for="${prefix}-url">Evidence URL (optional)<input id="${prefix}-url" name="evidenceUrl" type="url" maxlength="2000" placeholder="https://…"></label>
        <label for="${prefix}-status">Your classification<select id="${prefix}-status" name="status"><option value="unknown">Unknown / not yet assessed</option><option value="support">Supplied evidence supports</option><option value="conflict">Supplied evidence conflicts</option></select></label>
      </div>
      <label for="${prefix}-note">Evidence note (optional)<textarea id="${prefix}-note" name="note" rows="2" maxlength="6000" placeholder="What does the source actually say? What remains uncertain?"></textarea></label>
      <div class="tool-actions"><button type="submit">Add claim</button></div>
    </form>
    <div class="error" role="alert"></div>
    <p class="muted" role="status" aria-live="polite"></p>
    <div class="tool-actions"><button type="button" data-export>Export JSON</button><label for="${prefix}-import">Import JSON (replaces this list)<input id="${prefix}-import" type="file" accept=".json,application/json"></label></div>
    <div class="tool-result" aria-label="Claim ledger"></div>`;
  const form = container.querySelector('form');
  const error = container.querySelector('.error');
  const status = container.querySelector('[role="status"]');
  const result = container.querySelector('.tool-result');
  const exportButton = container.querySelector('[data-export]');
  const importInput = container.querySelector('input[type="file"]');
  const labels = { support: 'Supplied evidence supports', conflict: 'Supplied evidence conflicts', unknown: 'Unknown / not yet assessed' };

  function render() {
    result.replaceChildren();
    exportButton.disabled = claims.length === 0;
    if (!claims.length) {
      const empty = document.createElement('p');
      empty.className = 'muted';
      empty.textContent = 'No claims yet. Add a statement, then record what your evidence suggests.';
      result.append(empty);
      return;
    }
    for (const claim of claims) {
      const article = document.createElement('article');
      article.className = 'claim-entry';
      const heading = document.createElement('h4');
      heading.textContent = claim.text;
      const classification = document.createElement('p');
      classification.className = 'muted';
      classification.textContent = labels[claim.status];
      article.append(heading, classification);
      if (claim.evidenceUrl) {
        const paragraph = document.createElement('p');
        const link = document.createElement('a');
        link.href = claim.evidenceUrl;
        link.textContent = claim.evidenceUrl;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        paragraph.append(link);
        article.append(paragraph);
      }
      if (claim.note) {
        const note = document.createElement('p');
        note.textContent = claim.note;
        article.append(note);
      }
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.textContent = 'Remove claim';
      remove.setAttribute('aria-label', `Remove claim: ${claim.text.slice(0, 80)}`);
      remove.addEventListener('click', () => {
        claims = removeClaim(claims, claim.id);
        status.textContent = `Claim removed. ${claims.length} remaining.`;
        render();
        form.elements.namedItem('text').focus();
      });
      article.append(remove);
      result.append(article);
    }
  }

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    try {
      let id;
      do { id = `claim-${++sequence}`; } while (claims.some((claim) => claim.id === id));
      const input = Object.fromEntries(['text', 'evidenceUrl', 'note', 'status'].map((name) => [name, form.elements.namedItem(name).value]));
      claims = addClaim(claims, input, id);
      error.textContent = '';
      status.textContent = `Claim added. ${claims.length} in this tab. Export JSON to keep a copy.`;
      form.reset();
      render();
      form.elements.namedItem('text').focus();
    } catch (problem) { error.textContent = problem.message; }
  });

  exportButton.addEventListener('click', () => {
    const blob = new Blob([exportLedger(claims)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'roary-claim-ledger.json';
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    status.textContent = 'JSON export prepared. Keep the downloaded file to restore this ledger.';
  });

  importInput.addEventListener('change', async () => {
    const file = importInput.files?.[0];
    if (!file) return;
    try {
      if (file.size > MAX_FILE_CHARACTERS) throw new RangeError('Import a JSON file smaller than 2 MB.');
      const imported = importLedger(await file.text());
      claims = imported;
      error.textContent = '';
      status.textContent = `Imported ${claims.length} claims. The previous list has been replaced.`;
      render();
    } catch (problem) { error.textContent = problem.message; }
    finally { importInput.value = ''; }
  });
  render();
}
