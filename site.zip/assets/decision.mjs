const clean = (value) => typeof value === 'string' ? value.trim() : '';

export function calculateDecision(input = {}) {
  if (!Array.isArray(input.options) || input.options.length < 2) throw new Error('Add at least two options.');
  const options = input.options.map(clean);
  if (options.some((option) => !option)) throw new Error('Give every option a name.');
  if (new Set(options.map((option) => option.toLowerCase())).size !== options.length) throw new Error('Use a different name for each option.');
  if (!Array.isArray(input.criteria) || !input.criteria.length) throw new Error('Add at least one criterion.');
  const criteria = input.criteria.map((criterion) => {
    const name = clean(criterion?.name);
    const weight = criterion?.weight;
    if (!name) throw new Error('Give every criterion a name.');
    if (typeof weight !== 'number' || !Number.isFinite(weight) || weight < 0) throw new Error('Weights must be finite numbers of 0 or greater.');
    return { name, weight };
  });
  const totalWeight = criteria.reduce((total, criterion) => total + criterion.weight, 0);
  if (!Number.isFinite(totalWeight)) throw new Error('Reduce the weights so their total is finite.');
  if (totalWeight === 0) throw new Error('Give at least one criterion a positive weight.');
  if (!Array.isArray(input.scores) || input.scores.length !== options.length) throw new Error('Supply one score row per option.');
  const scores = input.scores.map((row) => {
    if (!Array.isArray(row) || row.length !== criteria.length) throw new Error('Score every option against every criterion.');
    return row.map((value) => {
      if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 5) throw new Error('Every score must be a number from 0 to 5.');
      return value;
    });
  });
  const results = options.map((name, index) => ({
    name,
    score: scores[index].reduce((total, value, criterion) => total + (value / 5) * (criteria[criterion].weight / totalWeight) * 100, 0),
  }));
  const highest = Math.max(...results.map((option) => option.score));
  const winners = results.filter((option) => Math.abs(option.score - highest) < 1e-9).map((option) => option.name);
  return { options, criteria, scores, totalWeight, results, winners, tie: winners.length > 1 };
}

export function analyseSensitivity(input = {}) {
  const baseline = calculateDecision(input);
  const scenarios = baseline.criteria.map((criterion, index) => {
    const criteria = baseline.criteria.map((item, position) => ({ ...item, weight: position === index ? 0 : item.weight }));
    if (criteria.every((item) => item.weight === 0)) {
      return { criterion: criterion.name, index, available: false, winners: [], changed: null, results: [], reason: 'No positive weight remains when this criterion is excluded.' };
    }
    const result = calculateDecision({ options: baseline.options, criteria, scores: baseline.scores });
    return {
      criterion: criterion.name, index, available: true,
      winners: result.winners, results: result.results,
      changed: JSON.stringify(result.winners) !== JSON.stringify(baseline.winners), reason: '',
    };
  });
  return { baseline, scenarios };
}

export function mount(container) {
  const doc = container.ownerDocument;
  const element = (tag, text, className = '') => {
    const node = doc.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (className) node.className = className;
    return node;
  };
  container.innerHTML = `
    <p>Make a trade-off visible. Choose the options, decide what matters, and test how much the result depends on your assumptions.</p>
    <p class="muted">Your entries stay in this page’s memory until you leave or reload. Scores express your judgement; they are not an objective recommendation.</p>
    <p class="error" role="alert" hidden></p>
    <form class="tool-form">
      <fieldset><legend>Your options</legend><div class="field-grid" data-options></div><button type="button" data-add-option>Add option</button></fieldset>
      <fieldset><legend>Criteria and weights</legend>
        <p class="muted">Weights set relative importance: a weight of 4 counts twice as much as 2. A weight of 0 excludes a criterion.</p>
        <div data-criteria></div><button type="button" data-add-criterion>Add criterion</button>
      </fieldset>
      <fieldset><legend>Score every option</legend>
        <p class="muted">Use 0 = worst and 5 = best. For cost or effort, a higher score must mean lower cost or less effort.</p>
        <div data-score-table style="overflow-x:auto"></div>
      </fieldset>
      <label>Assumptions or evidence (optional)<textarea name="assumptions" rows="3" placeholder="What do these scores depend on? What would change your mind?"></textarea></label>
      <label><input type="checkbox" name="sensitivity" checked> Test the result with each criterion excluded in turn</label>
      <div class="tool-actions"><button type="submit">Compare options</button><button type="button" data-example>Load illustrative example</button><button type="button" data-clear>Clear scores</button></div>
    </form>
    <section class="tool-result" data-result hidden aria-label="Decision comparison" aria-live="polite"></section>
    <div class="tool-actions"><button type="button" data-export disabled>Export decision JSON</button></div>
    <p class="muted">The calculation assumes criteria can be added together and that a one-point score change means the same thing across criteria. Sensitivity checks only exclude one criterion at a time; they do not establish that your assumptions are correct.</p>`;

  const form = container.querySelector('form');
  const optionsArea = container.querySelector('[data-options]');
  const criteriaArea = container.querySelector('[data-criteria]');
  const tableArea = container.querySelector('[data-score-table]');
  const resultArea = container.querySelector('[data-result]');
  const error = container.querySelector('.error');
  const exportButton = container.querySelector('[data-export]');
  const addOption = container.querySelector('[data-add-option]');
  const addCriterion = container.querySelector('[data-add-criterion]');
  let state = {
    options: ['Option A', 'Option B'],
    criteria: [{ name: 'Value to users', weight: 3 }, { name: 'Ease of delivery', weight: 2 }, { name: 'Lower running cost', weight: 1 }],
    scores: [[null, null, null], [null, null, null]],
  };
  let record = null;
  const showError = (message = '') => { error.textContent = message; error.hidden = !message; };
  const invalidate = () => {
    record = null;
    exportButton.disabled = true;
    if (!resultArea.hidden) {
      resultArea.replaceChildren(element('p', 'Inputs changed. Compare options again to update this result.'));
    }
    showError();
  };
  const capture = () => {
    state = {
      options: [...optionsArea.querySelectorAll('input')].map((field) => field.value),
      criteria: [...criteriaArea.querySelectorAll('[data-criterion-row]')].map((row) => ({
        name: row.querySelector('[data-name]').value,
        weight: row.querySelector('[data-weight]').value,
      })),
      scores: state.options.map((_, option) => state.criteria.map((__, criterion) => {
        const value = tableArea.querySelector(`[data-score="${option}-${criterion}"]`).value;
        return value === '' ? null : Number(value);
      })),
    };
  };
  const numericInput = (value, min, max, step) => {
    const input = element('input');
    input.type = 'number';
    input.min = String(min);
    if (max !== undefined) input.max = String(max);
    input.step = step;
    input.required = true;
    input.value = value ?? '';
    return input;
  };
  const updateTableLabels = () => {
    const optionNames = [...optionsArea.querySelectorAll('input')].map((field, index) => field.value.trim() || `Option ${index + 1}`);
    const criterionNames = [...criteriaArea.querySelectorAll('[data-name]')].map((field, index) => field.value.trim() || `Criterion ${index + 1}`);
    criterionNames.forEach((name, index) => { tableArea.querySelector(`[data-column="${index}"]`).textContent = name; });
    optionNames.forEach((name, index) => { tableArea.querySelector(`[data-row="${index}"]`).textContent = name; });
    optionNames.forEach((option, row) => criterionNames.forEach((criterion, column) => {
      tableArea.querySelector(`[data-score="${row}-${column}"]`).setAttribute('aria-label', `${option}: ${criterion}, score from 0 to 5`);
    }));
  };

  function renderEditor() {
    optionsArea.replaceChildren();
    state.options.forEach((name, index) => {
      const group = element('div');
      const label = element('label', `Option ${index + 1}`);
      const input = element('input');
      input.value = name;
      input.required = true;
      input.maxLength = 100;
      label.append(input);
      const remove = element('button', `Remove option ${index + 1}`);
      remove.type = 'button';
      remove.disabled = state.options.length <= 2;
      remove.addEventListener('click', () => {
        capture();
        state.options.splice(index, 1);
        state.scores.splice(index, 1);
        invalidate();
        renderEditor();
        addOption.focus();
      });
      group.append(label, remove);
      optionsArea.append(group);
    });
    criteriaArea.replaceChildren();
    state.criteria.forEach((criterion, index) => {
      const row = element('div', undefined, 'field-grid');
      row.dataset.criterionRow = String(index);
      const nameLabel = element('label', `Criterion ${index + 1}`);
      const name = element('input');
      name.value = criterion.name;
      name.required = true;
      name.maxLength = 100;
      name.dataset.name = '';
      nameLabel.append(name);
      const weightLabel = element('label', `Criterion ${index + 1} weight`);
      const weight = numericInput(criterion.weight, 0, undefined, 'any');
      weight.dataset.weight = '';
      weightLabel.append(weight);
      const remove = element('button', `Remove criterion ${index + 1}`);
      remove.type = 'button';
      remove.disabled = state.criteria.length <= 1;
      remove.addEventListener('click', () => {
        capture();
        state.criteria.splice(index, 1);
        state.scores.forEach((scores) => scores.splice(index, 1));
        invalidate();
        renderEditor();
        addCriterion.focus();
      });
      row.append(nameLabel, weightLabel, remove);
      criteriaArea.append(row);
    });
    const table = element('table');
    table.append(element('caption', 'Option scores, from 0 (worst) to 5 (best)'));
    const head = element('thead');
    const header = element('tr');
    const corner = element('th', 'Option');
    corner.scope = 'col';
    header.append(corner);
    state.criteria.forEach((criterion, index) => {
      const cell = element('th', criterion.name);
      cell.scope = 'col';
      cell.dataset.column = String(index);
      header.append(cell);
    });
    head.append(header);
    table.append(head);
    const body = element('tbody');
    state.options.forEach((option, rowIndex) => {
      const row = element('tr');
      const label = element('th', option);
      label.scope = 'row';
      label.dataset.row = String(rowIndex);
      row.append(label);
      state.criteria.forEach((criterion, column) => {
        const cell = element('td');
        const input = numericInput(state.scores[rowIndex][column], 0, 5, 'any');
        input.dataset.score = `${rowIndex}-${column}`;
        input.style.minWidth = '5rem';
        cell.append(input);
        row.append(cell);
      });
      body.append(row);
    });
    table.append(body);
    tableArea.replaceChildren(table);
    addOption.disabled = state.options.length >= 5;
    addCriterion.disabled = state.criteria.length >= 8;
    updateTableLabels();
  }

  addOption.addEventListener('click', () => {
    capture();
    if (state.options.length >= 5) return;
    state.options.push('');
    state.scores.push(state.criteria.map(() => null));
    invalidate();
    renderEditor();
    [...optionsArea.querySelectorAll('input')].at(-1).focus();
  });
  addCriterion.addEventListener('click', () => {
    capture();
    if (state.criteria.length >= 8) return;
    state.criteria.push({ name: '', weight: 1 });
    state.scores.forEach((scores) => scores.push(null));
    invalidate();
    renderEditor();
    [...criteriaArea.querySelectorAll('[data-name]')].at(-1).focus();
  });
  form.addEventListener('input', () => { invalidate(); updateTableLabels(); });
  form.addEventListener('change', invalidate);

  container.querySelector('[data-example]').addEventListener('click', () => {
    state = {
      options: ['Small browser tool', 'Larger connected service'],
      criteria: [{ name: 'Value to users', weight: 3 }, { name: 'Ease of delivery', weight: 2 }, { name: 'Lower running cost', weight: 1 }],
      scores: [[3, 5, 5], [5, 2, 1]],
    };
    form.elements.namedItem('assumptions').value = 'Illustrative scores only. Assumes an early prototype, limited build time and no existing audience research. Replace these assumptions with your own evidence.';
    invalidate();
    renderEditor();
  });
  container.querySelector('[data-clear]').addEventListener('click', () => {
    capture();
    state.scores = state.options.map(() => state.criteria.map(() => null));
    invalidate();
    renderEditor();
    tableArea.querySelector('input').focus();
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    try {
      capture();
      const input = {
        options: state.options,
        criteria: state.criteria.map((criterion) => ({ name: criterion.name, weight: criterion.weight === '' ? NaN : Number(criterion.weight) })),
        scores: state.scores,
      };
      const comparison = calculateDecision(input);
      const sensitivity = form.elements.namedItem('sensitivity').checked ? analyseSensitivity(input) : null;
      record = {
        schemaVersion: 1, kind: 'user-weighted-decision',
        limit: 'An additive model of supplied assumptions, not an objective recommendation.',
        assumptions: form.elements.namedItem('assumptions').value.trim(),
        comparison, sensitivity: sensitivity?.scenarios ?? null,
      };
      resultArea.replaceChildren();
      resultArea.append(element('h4', comparison.tie ? `Tie: ${comparison.winners.join(', ')}` : `Highest weighted score: ${comparison.winners[0]}`));
      const list = element('ul');
      comparison.results.forEach((option) => list.append(element('li', `${option.name}: ${option.score.toFixed(2)}/100`)));
      resultArea.append(list);
      resultArea.append(element('p', 'Weighted score = Σ(score ÷ 5 × weight) ÷ total weight × 100.', 'muted'));
      const weights = element('p', `Weights used: ${comparison.criteria.map((criterion) => `${criterion.name} = ${criterion.weight}`).join('; ')}.`, 'muted');
      resultArea.append(weights);
      resultArea.append(element('p', record.assumptions ? `Your assumptions: ${record.assumptions}` : 'No supporting assumptions or evidence recorded.', 'muted'));
      if (sensitivity) {
        resultArea.append(element('h4', 'What if a criterion is excluded?'));
        const scenarios = element('ul');
        sensitivity.scenarios.forEach((scenario) => {
          const outcome = !scenario.available ? scenario.reason : `${scenario.winners.length > 1 ? 'Tie' : 'Highest score'}: ${scenario.winners.join(', ')}. ${scenario.changed ? 'The leading option changes.' : 'The leading option stays the same.'}`;
          scenarios.append(element('li', `Without ${scenario.criterion}: ${outcome}`));
        });
        resultArea.append(scenarios);
      }
      resultArea.hidden = false;
      exportButton.disabled = false;
      showError();
    } catch (failure) { showError(failure.message); }
  });

  exportButton.addEventListener('click', () => {
    if (!record) return;
    const url = URL.createObjectURL(new Blob([JSON.stringify(record, null, 2)], { type: 'application/json' }));
    const link = element('a');
    link.href = url;
    link.download = 'roary-decision.json';
    container.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
  renderEditor();
}
