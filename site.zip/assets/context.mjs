/** A deliberately rough planning heuristic, not a model or provider tokenizer. */
export function estimateTokens(text) {
  if (typeof text !== 'string') throw new TypeError('Text must be a string.');
  const characterCount = Array.from(text).length;
  return { characterCount, estimatedTokens: Math.ceil(characterCount / 4) };
}

function numeric(value, name, { integer = false, positive = false } = {}) {
  if ((typeof value !== 'string' && typeof value !== 'number') || (typeof value === 'string' && !value.trim())) {
    throw new TypeError(`${name} needs a number.`);
  }
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0 || (positive && number === 0) || (integer && !Number.isSafeInteger(number))) {
    throw new RangeError(`${name} must be ${positive ? 'a positive' : 'a non-negative'} ${integer ? 'whole number' : 'number'}.`);
  }
  return number;
}

export function analyseContext({ text = '', contextLimit, replyReserve, systemReserve, inputRate, outputRate } = {}) {
  const estimate = estimateTokens(text);
  const limit = numeric(contextLimit, 'Context limit', { integer: true, positive: true });
  const reply = numeric(replyReserve, 'Reply reserve', { integer: true });
  const system = numeric(systemReserve, 'System and other input reserve', { integer: true });
  const estimatedInputTokens = estimate.estimatedTokens + system;
  const totalReservedTokens = estimatedInputTokens + reply;
  if (!Number.isSafeInteger(totalReservedTokens)) throw new RangeError('Combined token budget is too large.');
  const hasCosts = inputRate !== undefined || outputRate !== undefined;
  let estimatedInputCostUsd = null;
  let estimatedOutputCostUsd = null;
  let estimatedTotalCostUsd = null;
  if (hasCosts) {
    const input = numeric(inputRate, 'Input rate');
    const output = numeric(outputRate, 'Output rate');
    estimatedInputCostUsd = estimatedInputTokens / 1_000_000 * input;
    estimatedOutputCostUsd = reply / 1_000_000 * output;
    estimatedTotalCostUsd = estimatedInputCostUsd + estimatedOutputCostUsd;
    if (!Number.isFinite(estimatedTotalCostUsd)) throw new RangeError('The cost estimate is too large.');
  }
  return {
    characterCount: estimate.characterCount,
    estimatedTextTokens: estimate.estimatedTokens,
    estimatedInputTokens,
    inputBudget: Math.max(0, limit - reply - system),
    totalReservedTokens,
    availableTokens: Math.max(0, limit - totalReservedTokens),
    overflowTokens: Math.max(0, totalReservedTokens - limit),
    fits: totalReservedTokens <= limit,
    estimatedInputCostUsd,
    estimatedOutputCostUsd,
    estimatedTotalCostUsd,
  };
}

export function createBudgetSnapshot(input = {}) {
  const result = analyseContext(input);
  const hasCosts = input.inputRate !== undefined || input.outputRate !== undefined;
  return {
    format: 'roary-context-budget',
    version: 1,
    estimate: {
      method: 'Unicode code points divided by 4, rounded up; text only, with manually reserved system and reply tokens.',
      approximate: true,
      providerTokenizer: false,
      currentProviderPricingIncluded: false,
      costBasis: 'Only supplied manual USD rates; assumes uncached input and the full reply reserve. Excludes taxes, tool calls and other charges.',
    },
    supplied: {
      text: input.text ?? '',
      contextLimit: Number(input.contextLimit),
      replyReserve: Number(input.replyReserve),
      systemReserve: Number(input.systemReserve),
      manualRates: hasCosts ? { currency: 'USD', inputPerMillion: Number(input.inputRate), outputPerMillion: Number(input.outputRate) } : null,
    },
    result,
  };
}

let mounts = 0;

export function mount(container) {
  const prefix = `context-${++mounts}`;
  container.innerHTML = `
    <p class="muted">A quick planning aid using Unicode code points ÷ 4, rounded up. This is a rough estimate, not a provider tokenizer. Languages, code and special tokens can differ substantially. Leave a margin and check the actual tokenizer before a large request.</p>
    <form class="tool-form" novalidate>
      <label for="${prefix}-text">Text to send</label>
      <textarea id="${prefix}-text" name="text" rows="6" placeholder="Paste a draft, document or prompt…"></textarea>
      <div class="field-grid">
        <label for="${prefix}-limit">Context limit (tokens)<input id="${prefix}-limit" name="contextLimit" type="number" min="1" step="1" value="32000" required></label>
        <label for="${prefix}-reply">Reserve for reply (tokens)<input id="${prefix}-reply" name="replyReserve" type="number" min="0" step="1" value="4000" required></label>
        <label for="${prefix}-system">Reserve for system prompt and other inputs (tokens)<input id="${prefix}-system" name="systemReserve" type="number" min="0" step="1" value="1000" required></label>
      </div>
      <label for="${prefix}-costs"><input id="${prefix}-costs" name="includeCosts" type="checkbox"> Include a cost estimate using my own rates</label>
      <fieldset hidden>
        <legend>Manual rates in USD per million tokens</legend>
        <p class="muted">Enter the rates for your chosen model. No current pricing is supplied. Assumes uncached input and the full reply reserve is used; excludes taxes, tool calls and other charges.</p>
        <div class="field-grid">
          <label for="${prefix}-input-rate">Input rate (USD / million)<input id="${prefix}-input-rate" name="inputRate" type="number" min="0" step="any" value="0" disabled></label>
          <label for="${prefix}-output-rate">Output rate (USD / million)<input id="${prefix}-output-rate" name="outputRate" type="number" min="0" step="any" value="0" disabled></label>
        </div>
      </fieldset>
    </form>
    <div class="error" role="alert"></div>
    <div class="tool-result" role="status" aria-live="polite" aria-atomic="true"></div>
    <div class="tool-actions"><button type="button" data-export disabled>Export budget JSON</button></div>`;
  const form = container.querySelector('form');
  const field = (name) => form.elements.namedItem(name);
  const result = container.querySelector('.tool-result');
  const error = container.querySelector('.error');
  const costs = container.querySelector('fieldset');
  const exportButton = container.querySelector('[data-export]');
  let currentSnapshot = null;
  const format = (number) => number.toLocaleString('en-AU');
  const money = (value) => value.toLocaleString('en-AU', { style: 'currency', currency: 'USD', minimumFractionDigits: 6, maximumFractionDigits: 6 });
  function update() {
    const includeCosts = field('includeCosts').checked;
    costs.hidden = !includeCosts;
    field('inputRate').disabled = !includeCosts;
    field('outputRate').disabled = !includeCosts;
    try {
      const values = Object.fromEntries(['text', 'contextLimit', 'replyReserve', 'systemReserve'].map((name) => [name, field(name).value]));
      if (includeCosts) {
        values.inputRate = field('inputRate').value;
        values.outputRate = field('outputRate').value;
      }
      currentSnapshot = createBudgetSnapshot(values);
      const budget = currentSnapshot.result;
      exportButton.disabled = false;
      error.textContent = '';
      result.replaceChildren();
      const summary = document.createElement('p');
      summary.textContent = budget.fits ? `Estimated room remaining: ${format(budget.availableTokens)} tokens.` : `Estimated overflow: ${format(budget.overflowTokens)} tokens. Reduce the text or reserves, or choose a larger context limit.`;
      result.append(summary);
      const list = document.createElement('dl');
      const entries = [
        ['Characters (Unicode code points)', format(budget.characterCount)],
        ['Estimated text tokens', format(budget.estimatedTextTokens)],
        ['Text budget after reserves', `${format(budget.inputBudget)} tokens`],
        ['Total text + system + reply', `${format(budget.totalReservedTokens)} tokens`],
      ];
      if (includeCosts) entries.push(['Estimated input cost (USD)', money(budget.estimatedInputCostUsd)], ['Estimated reserved reply cost (USD)', money(budget.estimatedOutputCostUsd)], ['Estimated total cost (USD)', money(budget.estimatedTotalCostUsd)]);
      for (const [label, value] of entries) {
        const term = document.createElement('dt');
        const detail = document.createElement('dd');
        term.textContent = label;
        detail.textContent = value;
        list.append(term, detail);
      }
      result.append(list);
    } catch (problem) {
      currentSnapshot = null;
      exportButton.disabled = true;
      error.textContent = problem.message;
      result.replaceChildren();
    }
  }
  form.addEventListener('input', update);
  form.addEventListener('submit', (event) => event.preventDefault());
  exportButton.addEventListener('click', () => {
    if (!currentSnapshot) return;
    const blob = new Blob([JSON.stringify(currentSnapshot, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'roary-context-budget.json';
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
  update();
}
