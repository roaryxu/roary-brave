# Font licences

These open-source fonts are served from this website; visitors make no font requests to Google.

## Alegreya

Source: https://fonts.gstatic.com/s/alegreya/v41/4UaBrEBBsBhlBjvfkSLhx6g.woff2

Licence: https://raw.githubusercontent.com/google/fonts/main/ofl/alegreya/OFL.txt

## Alegreya italic

Source: https://fonts.gstatic.com/s/alegreya/v41/4UaHrEBBsBhlBjvfkSLk96rp5w.woff2

Licence: https://raw.githubusercontent.com/google/fonts/main/ofl/alegreya/OFL.txt

## Commissioner

Source: https://fonts.gstatic.com/s/commissioner/v24/tDbw2o2WnlgI0FNDgduEk4jAhwgumbU1SVfU5BD8OuRL8OstC6KOhgvBYWSFJ-Mgdrgiju6fF8m0akXa.woff2

Licence: https://raw.githubusercontent.com/google/fonts/main/ofl/commissioner/OFL.txt

## Headline faces acquired 19 October 2026

The following unmodified WOFF2 Latin subsets were downloaded from the `src` URLs in the official [Google Fonts CSS response](https://fonts.googleapis.com/css2?family=Gentium+Plus:ital,wght@0,400;1,400&family=Prociono&display=swap). The request used a Chrome user agent; the response declares `font-display: swap` and the styles and weights below. Serve the local files from `assets/`; the remote CSS is provenance, not a page dependency.

| Local file | Face | Weight | Source |
| --- | --- | --- | --- |
| `prociono-latin.woff2` | Prociono, normal | 400 | [Google Fonts, Prociono v28](https://fonts.gstatic.com/s/prociono/v28/r05YGLlR-KxAf9GGO_uuwjc.woff2) |
| `gentium-plus-latin.woff2` | Gentium Plus, normal | 400 | [Google Fonts, Gentium Plus v2](https://fonts.gstatic.com/s/gentiumplus/v2/Iurd6Ytw-oSPaZ00r2bNe8VZi5FN.woff2) |
| `gentium-plus-italic-latin.woff2` | Gentium Plus, italic | 400 | [Google Fonts, Gentium Plus v2](https://fonts.gstatic.com/s/gentiumplus/v2/IurD6Ytw-oSPaZ00r2bNe8VZjqFPwGk.woff2) |

FontTools parsed all three files successfully. Each has a `wOF2` signature and weight 400. Internal font versions are Prociono 2.301 and Gentium Plus 6.101. The Gentium Plus italic has the italic flags set and an italic angle of −8 degrees; it is a supplied italic face, not a browser-generated slant. All three include the characters in the current headline and “I’m Roary.”

These are Latin subsets, with the following Google Fonts Unicode range:

```text
U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA,
U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122,
U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
```

### Notices and redistribution

- Prociono: copyright 2011 Barry Schwartz. Keep [prociono-OFL.txt](prociono-OFL.txt), downloaded from the official [Google Fonts notice](https://raw.githubusercontent.com/google/fonts/main/ofl/prociono/OFL.txt).
- Gentium Plus: copyright 2003–2022 SIL International, with Reserved Font Names “Gentium” and “SIL”. Keep [gentium-plus-OFL.txt](gentium-plus-OFL.txt), downloaded from the official [Google Fonts notice](https://raw.githubusercontent.com/google/fonts/main/ofl/gentiumplus/OFL.txt).

Both use SIL Open Font License 1.1. Redistribution with the website is permitted while retaining the copyright and licence notices. Do not sell the font files by themselves. Modified fonts remain under the OFL and must respect any Reserved Font Names; these downloaded files have not been modified. The licence does not require website text or other content to use the OFL.
